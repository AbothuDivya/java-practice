package practiceproject_2;

class Pubaccessspecifiers {

	public void display() {
		System.out.println("This is Public Access Specifiers");
	}
}

public class AccessSpecifiers4 {

	public static void main(String[] args) {

		Pubaccessspecifiers obj = new Pubaccessspecifiers();
		obj.display();

	}
}
