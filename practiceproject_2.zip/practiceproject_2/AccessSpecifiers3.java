package practiceproject_2;

class Proaccessspecifiers {

	protected void display() {
		System.out.println("This is protected access specifier");
	}
}

public class AccessSpecifiers3 extends Proaccessspecifiers {

	public static void main(String[] args) {
		AccessSpecifiers3 obj = new AccessSpecifiers3();
		obj.display();
	}

}
